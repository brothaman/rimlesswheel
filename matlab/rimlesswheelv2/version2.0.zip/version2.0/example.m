clc
clear all

options = dopset('Events',1,'AbsTol',1e-10,'RelTol',1e-10,'EventTol',1e-11);
[t,y,te,ye,ie,stats] = dop853('lorenz',[0 50],[5;-5;2],options,[10;28;8/3]);
%[t,y,te,ye,ie,stats] = dop853_lorenz([0 50],[5;-5;2],options,[10;28;8/3]);
figure;
plot3(y(:,1),y(:,2),y(:,3));
hold on;
plot3(ye(:,1),ye(:,2),ye(:,3),'ro')