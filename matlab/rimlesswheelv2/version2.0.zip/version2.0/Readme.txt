Sep 16, 2015

Installation on os yosemite.
Assumes you have a working version of MATLAB and XCode or similar C compiler already installed


Instructions for installation:
0) set C compiler by doing mex -setup C
1) open instaldop853 and run, say yes to mex question
2) say yes to gsl question and point to the correct gsl directory or give a random directory if you dont need gsl. (need to do twice)
3) Make following changes to integrator.cpp change malloc.h to malloc/malloc.h
4) Make following changes to makedop853.m 
	i) comment out 113 to 118
	ii) remove the word �libstr� from line 228
5) Set the folder �examples� in the installation in the MATLAB path using �set path� option�.
6) Now you are ready to start: in matlab prompt
>cd examples
>options = dopset('Events',1,'AbsTol',1e-10,'RelTol',1e-10,'EventTol',1e-11);
>[t,y,te,ye,ie,stats] = dop853('lorenz',[0 50],[5;-5;2],options,[10;28;8/3]);
>plot3(y(:,1),y(:,2),y(:,3));


Instruction for uninstallation:
Run uninstalldop853.m
If that does not work do the following in the MATLAB prompt: rmpref('mexdop853')

%%%%%%%%%% These read_me are by Madhusudan Venkadesan (the original author) %%%%%%%%
Bugs:
=====

1. If your system is a Mac (OS X, Snow Leopard), then edit the file integrator.cpp by changing the 3rd line using double quotes to read
#include "malloc.h"
Then, using the command terminal, copy /usr/include/malloc/malloc.h to the installation folder of mexdop853. This hack is needed because of Apple's non-standard include files.

2. Doesnt recognize -L option in mex. Help says it is only supported for unix.
So had to change line 212 in makedop853 from libstr = ['-L' '''' gsllibdir '''' ' -lcblas -lgsl'];
 to  libstr = '';

3. In matlab one can define Abstol as an array for different states (see ode help example 2). mexdop853 does not yet support this.

4. Bug with returned values for dop853 called with events. Example lines of code:
optionsdop =  dopset('Refine',2,'AbsTol',1e-13,'RelTol',1e-13,'Events',1,'EventTol',1e-13);
[t,y,te,ye,ie,stats]=dop853(@rhs,[t0 tend],y0,optionsdop,parms');
t(end) is not the same as te (and y(end,:) to be same as ye). This is not true when Refine option is set. This bug is annoying, and will be fixed. Will fix this soon.

Bugs 2-4 were identified by Pranav Bhounsule, including the fix for bug 2.


Code to run the Lorenz example:
===============================
options = dopset('Events',1,'AbsTol',1e-10,'RelTol',1e-10,'EventTol',1e-11);
[t,y,te,ye,ie,stats] = dop853('lorenz',[0 50],[5;-5;2],options,[10;28;8/3]);
figure;
plot3(y(:,1),y(:,2),y(:,3));
hold on;
plot3(ye(:,1),ye(:,2),ye(:,3),'ro')